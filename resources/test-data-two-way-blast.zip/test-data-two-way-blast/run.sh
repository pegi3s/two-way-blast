#!/bin/bash

# Edit the INPUT_DIR and OUTPUT_DIR variables
INPUT_DIR=/path/to/test-data-two-way-blast/data/
OUTPUT_DIR=/path/to/output/data/dir

REFERENCE=nucleotide.fasta
BLAST_TYPE=tblastx

# Adjust the COMPI_NUM_TASKS to an appropiate value
COMPI_NUM_TASKS=8

docker run --rm -v ${INPUT_DIR}:/input -v ${OUTPUT_DIR}:/output pegi3s/two-way-blast --num-tasks ${COMPI_NUM_TASKS} -q -- --reference_file ${REFERENCE} --blast_type ${BLAST_TYPE}
